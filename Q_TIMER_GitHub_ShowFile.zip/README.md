# Q TIMER

GitHub / Cloudflare Pages upload package.

- `index.html` : Q TIMER main app
- `icon.png` : iPhone home-screen icon

Upload these files to the root of the repository.
